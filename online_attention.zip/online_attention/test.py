print("VS Code + Python working!")
